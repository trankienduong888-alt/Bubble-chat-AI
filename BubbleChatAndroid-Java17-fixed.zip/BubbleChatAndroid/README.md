# Bubble Chat Android

Bản Android native viết bằng Kotlin + Jetpack Compose.

## Tạo APK bằng GitHub Actions

1. Giải nén ZIP và mở thư mục `BubbleChatAndroid`.
2. Đưa **toàn bộ nội dung bên trong** thư mục này (`app`, `.github`, `build.gradle.kts`, ...) vào thư mục gốc repository GitHub.
3. Mở tab **Actions** của repository.
4. Chọn **Build Bubble Chat APK** → **Run workflow**.
5. Chờ workflow hoàn tất thành công, mở lần chạy đó và tải artifact **BubbleChat-debug-apk**.
6. Giải nén artifact để lấy `app-debug.apk`, sau đó mở file trên điện thoại Android để cài đặt.

Workflow nằm tại `.github/workflows/main.yml`. Dự án không kèm Gradle Wrapper nên GitHub Actions cài Gradle 8.9 trực tiếp.

## Tình trạng ứng dụng

- Có giao diện chat bong bóng, gửi tin nhắn, tạo cuộc trò chuyện mới và đổi giao diện sáng/tối.
- Phản hồi hiện là nội dung mô phỏng để kiểm tra giao diện.
- Chưa kết nối mô hình AI, chưa đồng bộ lịch sử lên đám mây.
- Không nhập API key bí mật trực tiếp vào ứng dụng Android. Muốn dùng AI thật cần một backend bảo vệ khóa API.

## Thông tin kỹ thuật

- Package: `com.example.bubblechat`
- Min Android: Android 7.0 (API 24)
- Compile/Target SDK: 35
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- Java/Kotlin JVM target: 17

APK tạo ra là bản debug để thử nghiệm/cài thủ công, chưa phải bản phát hành ký số để đăng Google Play.
