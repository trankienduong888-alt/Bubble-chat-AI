package com.example.bubblechat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF10A37F)
private val Ink = Color(0xFF17211F)
private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BubbleChatScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BubbleChatScreen() {
    var input by remember { mutableStateOf("") }
    var waiting by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Xin chào! 👋 Mình là Bubble Chat. Hôm nay bạn muốn trò chuyện về điều gì?", false)
        )
    }

    val bg = if (dark) Color(0xFF101816) else Color(0xFFF7FAF9)
    val panel = if (dark) Color(0xFF1B2623) else Color.White
    val textColor = if (dark) Color(0xFFE8F0ED) else Ink

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Teal) else lightColorScheme(primary = Teal)) {
        Scaffold(
            containerColor = bg,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(38.dp).background(Teal, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.ChatBubble, null, tint = Color.White) }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Bubble Chat", fontWeight = FontWeight.Bold, color = textColor)
                                Text("Trợ lý trò chuyện", fontSize = 11.sp, color = Teal)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { messages.clear(); messages.add(ChatMessage("Cuộc trò chuyện mới bắt đầu. Bạn muốn hỏi gì?", false)) }) {
                            Icon(Icons.Default.Add, "Cuộc trò chuyện mới", tint = textColor)
                        }
                        IconButton(onClick = { dark = !dark }) {
                            Icon(Icons.Default.AutoAwesome, "Đổi giao diện", tint = textColor)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = panel)
                )
            },
            bottomBar = {
                Surface(color = panel, shadowElevation = 8.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.weight(1f).background(bg, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            if (input.isEmpty()) Text("Nhắn tin cho Bubble Chat...", color = Color.Gray)
                            BasicTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(color = textColor, fontSize = 15.sp),
                                maxLines = 5
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val msg = input.trim()
                                if (msg.isNotEmpty() && !waiting) {
                                    messages.add(ChatMessage(msg, true))
                                    input = ""
                                    waiting = true
                                    messages.add(ChatMessage("Mình đã nhận được tin nhắn của bạn. Đây hiện là bản thử nghiệm giao diện; cần kết nối máy chủ AI để tạo câu trả lời ChatGPT thực sự.", false))
                                    waiting = false
                                }
                            },
                            modifier = Modifier.size(48.dp).background(Teal, CircleShape)
                        ) { Icon(Icons.Default.ArrowUpward, "Gửi", tint = Color.White) }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            if (!msg.fromUser) {
                                Box(Modifier.size(28.dp).background(Teal, CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                Spacer(Modifier.width(7.dp))
                            }
                            Surface(
                                color = if (msg.fromUser) Color(0xFF2563EB) else panel,
                                shape = RoundedCornerShape(
                                    topStart = 18.dp, topEnd = 18.dp,
                                    bottomStart = if (msg.fromUser) 18.dp else 5.dp,
                                    bottomEnd = if (msg.fromUser) 5.dp else 18.dp
                                ),
                                tonalElevation = if (msg.fromUser) 0.dp else 1.dp
                            ) {
                                Text(
                                    msg.text,
                                    modifier = Modifier.widthIn(max = 290.dp).padding(horizontal = 15.dp, vertical = 12.dp),
                                    color = if (msg.fromUser) Color.White else textColor,
                                    fontSize = 15.sp,
                                    lineHeight = 21.sp
                                )
                            }
                        }
                    }
                }
                Text(
                    "Bản thử nghiệm • Chưa kết nối dịch vụ AI",
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
    }
}
