# Bubble Chat Android

Bản Android native viết bằng Kotlin + Jetpack Compose.

## Tạo APK
1. Cài Android Studio trên máy tính.
2. Giải nén `BubbleChatAndroid.zip`.
3. Mở thư mục `BubbleChatAndroid` bằng Android Studio.
4. Chờ Gradle Sync hoàn tất và cài Android SDK Platform 35 nếu Android Studio yêu cầu.
5. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug sẽ nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Tình trạng hiện tại
- Có giao diện chat bong bóng, gửi tin nhắn, tạo cuộc trò chuyện mới và đổi giao diện sáng/tối.
- Phản hồi hiện là nội dung mô phỏng để kiểm tra giao diện.
- Chưa kết nối mô hình AI, chưa đồng bộ lịch sử lên đám mây.
- Không nhập API key bí mật trực tiếp vào ứng dụng Android. Muốn dùng AI thật cần một backend bảo vệ khóa API.

## Thông tin kỹ thuật
- Package: `com.example.bubblechat`
- Min Android: Android 7.0 (API 24)
- Compile/Target SDK: 35

## Build APK trên máy chủ đám mây (GitHub Actions)
Dự án đã kèm workflow `.github/workflows/build-apk.yml`. Sau khi tải mã nguồn lên một repository GitHub:
1. Mở tab **Actions** của repository.
2. Chọn **Build Bubble Chat APK** → **Run workflow** (hoặc đẩy mã nguồn lên nhánh `main`/`master`).
3. Chờ tác vụ hoàn tất, mở lần chạy thành công và tải artifact **BubbleChat-debug-apk**.
4. Giải nén artifact để lấy `app-debug.apk`, rồi chuyển sang điện thoại Android để cài đặt.

Workflow chỉ tạo APK debug để thử nghiệm/cài thủ công, chưa phải bản phát hành ký số để đăng Google Play. Ứng dụng hiện vẫn dùng phản hồi mô phỏng, chưa kết nối AI thật.
